# Intermediate-JavaScript-Week-2
Photo Gallery
